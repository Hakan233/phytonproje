import datetime

class Library:
    #constructor reading the books.txt it needs to be under same folder otherwise filename needs to be changed
    def __init__(self, filename='books.txt') -> None:
        self.bookinfo = open(filename,'a+')

    #destrucor method it closes the file
    def __del__(self):
        self.bookinfo.close()

    def list_books(self):
        booklist = self.book_read_utility()
        for book in booklist:
            book_infos = book.split(',')
            print(f'Book Name: {book_infos[0]}, Author: {book_infos[1]}')
    
    def book_read_utility(self):
        self.bookinfo.seek(0)
        booklist = self.bookinfo.read().splitlines()
        return booklist

    @classmethod
    def isValidDate(year, month, day):
        try:
            datetime.date(year, month, day)
            return True
        except:
            return False
    
    def add_book(self):
        
        book_name = input('Enter name of the book:')
        book_author = input('Enter name of the author of the book:')
        try:
            book_release_date = input('Enter release date of the book (date needs to be formatted as dd/mm/yyyy):')
            date_list = book_release_date.split('/')
            book_release_date_result = datetime.date(day=int(date_list[0]), month=int(date_list[1]), year=int(date_list[2]))
            book_release_date_result = book_release_date_result.strftime('%d/%m/%Y')
            
        except ValueError:
            print('Please enter valid date according to format')

        try:
            book_pages = int(input('Enter number of pages of the book:'))
            newbook = f'\n{book_name},{book_author},{book_release_date_result},{book_pages}'
            self.bookinfo.write(newbook)
        except ValueError:
            print('Enter a valid integer for book pages')

    def remove_book(self, controlunit = False):
        book_title_remove = input('Enter the title of the book to remove:')
        booklist = self.book_read_utility()

        for book in booklist:
            book_details = book.split(',')
            if (book_details[0] == book_title_remove):
                booklist.remove(book)
                controlunit = True
                break
        self.bookinfo.truncate(0)
        for book in booklist:
            if book == booklist[-1]:
                self.bookinfo.write(f'{book}')
            else:
                self.bookinfo.write(f'{book}\n')
            self.bookinfo.flush()

        if controlunit == False:
            print('Please enter valid book name')

            

if __name__ == '__main__':
    lib = Library()
    print('*** MENU***')
    print("1) List Books")
    print("2) Add Book")
    print("3) Remove Book")
    
    choice = input("Please select/enter your choice:")
    if choice == '1':
        lib.list_books()
    elif choice == '2':
        lib.add_book()
    elif choice == '3':
        lib.remove_book()

